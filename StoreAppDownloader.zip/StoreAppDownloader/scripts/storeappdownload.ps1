﻿Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$form = New-Object System.Windows.Forms.Form
$form.Text = 'Microsoft Store APP Downloader'
$form.Size = New-Object System.Drawing.Size(550,200)
$form.StartPosition = 'CenterScreen'

$okButton = New-Object System.Windows.Forms.Button
$okButton.Location = New-Object System.Drawing.Point(10,120)
$okButton.Size = New-Object System.Drawing.Size(75,23)
$okButton.Text = 'Download'
$okButton.DialogResult = [System.Windows.Forms.DialogResult]::OK
$form.AcceptButton = $okButton
$form.Controls.Add($okButton)

$cancelButton = New-Object System.Windows.Forms.Button
$cancelButton.Location = New-Object System.Drawing.Point(85,120)
$cancelButton.Size = New-Object System.Drawing.Size(75,23)
$cancelButton.Text = 'Exit'
$cancelButton.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
$form.CancelButton = $cancelButton
$form.Controls.Add($cancelButton)

$label = New-Object System.Windows.Forms.Label
$label.Location = New-Object System.Drawing.Point(10,20)
$label.Size = New-Object System.Drawing.Size(280,20)
$label.Text = 'Please enter the Mircrosoft Store APP URL below:'
$form.Controls.Add($label)

$label2 = New-Object System.Windows.Forms.Label
$label2.Location = New-Object System.Drawing.Point(10,40)
$label2.Size = New-Object System.Drawing.Size(600,20)
$label2.Text = 'Example: https://apps.microsoft.com/store/detail/whatsapp-desktop/9NKSQGP7F2NH?hl=de-de&gl=DE'
$form.Controls.Add($label2)

$label3 = New-Object System.Windows.Forms.Label
$label3.Location = New-Object System.Drawing.Point(10,90)
$label3.Size = New-Object System.Drawing.Size(600,40)
$label3.Text = 'Output folder: Downloads Folder'
$form.Controls.Add($label3)

$textBox = New-Object System.Windows.Forms.TextBox
$textBox.Location = New-Object System.Drawing.Point(10,60)
$textBox.Size = New-Object System.Drawing.Size(500,20)
$form.Controls.Add($textBox)

$form.Topmost = $true

$form.Add_Shown({$textBox.Select()})
$result = $form.ShowDialog()

if ($result -eq [System.Windows.Forms.DialogResult]::OK)
{
    $url = $textBox.Text
    $url
}
#Get App No
$urlsplit = $url -split "[/?]"
$appno = $urlsplit[6]

#Get Packagefamily Name
$iwr= iwr "https://bspmts.mp.microsoft.com/v1/public/catalog/Retail/Products/$appno/applockerdata"
$content = $iwr.content
$contentsplit = $content -split "[:,]"
$pfn = $contentsplit[1]
$pfn = $pfn -replace '"',''
$pfn = $pfn -replace ' ',''

#Download App Packages
$directory = "$env:userprofile\Downloads\$pfn\Files"
Powershell.exe -ExecutionPolicy ByPass "&" '.\scripts\Get_Store_Downloads.ps1' -packageFamilyName $pfn -downloadFolder $directory -force
$objShell = New-Object -ComObject "Shell.Application"
$objShell.Explore($directory)

#PopUp Download Completed
[System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms')
[System.Windows.Forms.MessageBox]::Show('Download completed','Info')