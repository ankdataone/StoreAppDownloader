Microsoft Store App Downloader

Start MicrosoftStoreAppDownloader.cmd
Enter the URL of the Microsoft Store App. Example: https://apps.microsoft.com/store/detail/spotify-%E2%80%93-musik-und-podcasts/9NCBCSZSJRSB?hl=de-de&gl=DE
Click Download

Appx Files will be stored in your Download folder.
Wait until Windows File Explorer Opens the folder containing the Appx Files.